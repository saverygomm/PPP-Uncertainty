###### Success (Feasibility): S_Treatment ###############################

# Set up the empty dataframes for each summary result
S_results <- list()
S_mean_funded <- as.numeric()
S_sd_funded <- as.numeric()
S_mean_perform <- as.numeric()
S_sd_perform <- as.numeric()
S_probfund <- data.frame(unique_plan_num=data$unique_plan_num) # UPDATED TO data (545 unique) and unique_plan_num

# 2-level loop: Simulate uncertainty to Benefit & Cost and calculate CEA for species at multiple Budget levels
loops <-100 # Define number of loop

for (t in 1:nrow(sim_df)){
    ## Give a 'progress bar' to see what day you're up to in the loop               
    cat('sim_df',t,'/',nrow(sim_df),'\n')                                           
    
    ## Create place to store results
    results_df <- list()
    results_funded <- numeric()
    results_perform <- numeric()
    results_probfund <- data.frame(unique_plan_num=data$unique_plan_num) # UPDATED TO data (545 unique) and unique_plan_num
    
    for(i in 1:loops) {
        # Add uncertainty to S at species level (NOT B)
        datasim <- dataSpp %>%
            mutate(S=rBeta(1:length(dataSpp$S), dataSpp$S, sim_df[t,"UBS"])) 
        # Get back to B&S&Co at plan level
        datasim <- datasim %>%
            group_by(unique_plan_num) %>%
            summarise( 
                B = sum(B, na.rm = TRUE),
                S = mean(S, na.rm = TRUE), 
                Co = mean(Co, na.rm = TRUE), 
                SpeciesInPlan = mean(SpeciesInPlan, na.rm = TRUE), 
                Benefit_without_Mgmt = sum(Benefit_without_Mgmt, na.rm = TRUE),                 
                Benefit_with_Mgmt = sum(Benefit_with_Mgmt, na.rm = TRUE))                       
        # Convert Co for total plan to ANNUAL costs (divide by 50)
        datasim <- mutate(datasim, Co=(Co/50))
        # DO NOT add uncertainty to Co at plan level
        # datasim <- datasim %>%                                                                   
        #                 rowwise() %>%                                                                                       
        #                 mutate(Co = rnorm(1, mean = Co, sd = Co*sim_df[t,"UCo"]))                           
        # print(head(datasim)) # << CHECKS THAT relevant parameters are changing consistent with treatment
        # Calculate cost efficiency and outcome for each plan
        datasim <- datasim %>%
            mutate(CE=((B*S)/Co)) %>%
            arrange(desc(CE)) %>%
            mutate(CumSum=cumsum(Co)) %>% 
            mutate(Outcome=ifelse(CumSum>=sim_df[t,"UBudget"], 0, 1)) %>%
            arrange(unique_plan_num)
        # Determine number of plans funded and performance for each budget and treatment
        results_funded[i] <- sum(datasim$Outcome*datasim$SpeciesInPlan)
        subset_benefit_without_management <- filter(datasim, Outcome < 1)                           
        benefit_without_management <- sum(subset_benefit_without_management$Benefit_without_Mgmt)   
        # print(benefit_without_management) # << CHECKS THAT benefit without management changes
        results_perform[i] <- sum(sum(datasim$B*datasim$S*datasim$Outcome), benefit_without_management) 
        results_df[[i]] <- datasim
        results_probfund[,as.character(i+1)] <- datasim$Outcome
    }
    
    S_mean_funded[t] <- mean(results_funded)
    S_sd_funded[t] <- sd(results_funded)
    S_mean_perform[t] <- mean(results_perform)
    S_sd_perform[t] <- sd(results_perform)
    S_results[[t]] <- results_df
    S_probfund[,t+1] <- rowSums(results_probfund[,2:ncol(results_probfund)])/100 
} 

# 1 & 2) Create dataframe to hold results for mean +/- SD # Species Funded/Performance
# Numb Funded Species & Performance for each treatment 
S_output <- data.frame(Treatment=rep("S", nrow(sim_df)),
                       SimSet=sim_df$SimSet,
                       UBS=sim_df$UBS,
                       UCo=sim_df$UCo,
                       UBudget=sim_df$UBudget,
                       MeanFunded=round(S_mean_funded,1), 
                       SDFunded=round(S_sd_funded,2), 
                       MeanPerform=round(S_mean_perform,1),
                       SDPerform=round(S_sd_perform,2))

# Reattach names to the S_probfund
names(S_probfund) <- c("unique_plan_num", as.character(S_output$SimSet))


# 3) Calculate which species are always/never funded funded for each uncertainty/budget treatment
# For each Treatment (column), subset where value >0.99 and count rows for Always.
# For each Treatment (column), subset where value == 0 and count rows for Never. 
# df[df==""]<-NA
S_always <- S_probfund[,2:ncol(S_probfund)]
S_always[S_always > 0.99] <- 1
S_always[S_always <= 0.99] <- NA
S_always <- cbind(S_probfund[,1], S_always)

S_sometimes <- S_probfund[,2:ncol(S_probfund)] # Error in colSums(Co_never[, -1], na.rm = TRUE) : 'x' must be numeric
S_sometimes[S_sometimes == 0.00] <- NA
S_sometimes[S_sometimes > 0.99] <- NA
S_sometimes[!is.na(S_sometimes)] <- 1
S_sometimes <- cbind(S_probfund[,1], S_sometimes)

S_never <- S_probfund[,2:ncol(S_probfund)] # Error in colSums(S_never[, -1], na.rm = TRUE) : 'x' must be numeric
S_never[S_never != 0.00] <- NA
S_never[S_never == 0.00] <- 1
S_never <- cbind(S_probfund[,1], S_never)

# How many species, for each treatment are always/never funded? Add each parameter treatment (B, Co, BCo etc), as it is completed. 
S_probfund_results<- data.frame(NULL)
S_always<- colSums(S_always[,-1], na.rm=TRUE)
S_sometimes<- colSums(S_sometimes[,-1], na.rm=TRUE)
S_never<- colSums(S_never[,-1], na.rm=TRUE)
S_probfund_results<-rbind(S_always, S_sometimes, S_never)
# datatable((S_probfund_results))