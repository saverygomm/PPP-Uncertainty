###### BSCo_Treatment ###############################

# Set up the empty dataframes for each summary result
BSCo_results <- list()
BSCo_mean_funded <- as.numeric()
BSCo_sd_funded <- as.numeric()
BSCo_mean_perform <- as.numeric()
BSCo_sd_perform <- as.numeric()
BSCo_probfund <- data.frame(unique_plan_num=data$unique_plan_num) # UPDATED TO data (545 unique) and unique_plan_num


final <-data.frame(NA) # I MUST HAVE SOMETHING IN HERE OR IT DOESN'T WORK. 
saved<- data.frame(NA)
# 2-level loop: Simulate uncertainty to Benefit & Cost and calculate CEA for species at multiple Budget levels

# number of loops: 
loops <-100

for (t in 1:nrow(sim_df)){

    results_df <- list()
    results_funded <- numeric()
    results_perform <- numeric()
    results_probfund <- data.frame(unique_plan_num=data$unique_plan_num) # UPDATED TO data (545 unique) and unique_plan_num

    for(i in 1:loops) {
        # Add uncertainty to B&S at species level
        datasim <- dataSpp %>%
            mutate( B=rBeta(1:length(dataSpp$B), dataSpp$B, sim_df[t,"UBS"]), 
                    S=rBeta(1:length(dataSpp$S), dataSpp$S, sim_df[t,"UBS"])) 
        # Get back to B & S & Co at plan level
        datasim <- datasim %>%
            group_by(unique_plan_num) %>%
            summarise( 
                B = sum(B, na.rm = TRUE),
                S = mean(S, na.rm = TRUE), 
                Co = mean(Co, na.rm = TRUE), 
                SpeciesInPlan = mean(SpeciesInPlan, na.rm = TRUE), 
                Benefit_without_Mgmt = sum(Benefit_without_Mgmt, na.rm = TRUE),                 ######## ADD THIS #######
                Benefit_with_Mgmt = sum(Benefit_with_Mgmt, na.rm = TRUE))                       ######## ADD THIS #######
        # Convert Co for total plan to ANNUAL costs (divide by 50)
        datasim <- mutate(datasim, Co = (Co/50))
        # Add uncertainty to Co at plan level
        costs <- datasim %>%                                                                   ######## ADD THIS #######
            rowwise() %>%                                                                      ######## ADD THIS #######
            mutate(Co = rnorm(1, mean = Co, sd = Co*sim_df[t,"UCo"]))   ######## ADD THIS #######
        costs<-datasim[,7]
        
        }
        final[i]<-cbind(final,costs)
        # # Calculate cost efficiency and outcome for each plan
        # datasim <- datasim %>%
        #     mutate(CE=((B*S)/CoU)) %>%
        #     arrange(desc(CE)) %>%
        #     mutate(CumSum=cumsum(CoU), Outcome=ifelse(CumSum>=sim_df[t,"UBudget"], 0, 1)) %>% 
        #     arrange(unique_plan_num)
        # Determine number of plans funded and performance for each budget and treatment
        # results_funded[i] <- sum(datasim$Outcome*datasim$SpeciesInPlan)
        # benefit_without_management <- filter(datasim, Outcome < 1)                                      ######## ADD THIS #######
        # benefit_without_management <- sum(benefit_without_management$Benefit_without_Mgmt)              ######## ADD THIS #######
        # results_perform[i] <- sum(sum(datasim$B*datasim$S*datasim$Outcome), benefit_without_management) ######## REPLACE THIS #######
        # results_df[[i]] <- datasim
        # results_probfund[,as.character(i+1)] <- datasim$Outcome
        # starter<-datasim[,1:5]
       
    } 
    dim(datasim)
#     BSCo_mean_funded[t] <- mean(results_funded)
#     BSCo_sd_funded[t] <- sd(results_funded)
#     BSCo_mean_perform[t] <- mean(results_perform)
#     BSCo_sd_perform[t] <- sd(results_perform)
#     BSCo_results[[t]] <- results_df
#     BSCo_probfund[,t+1] <- rowSums(results_probfund[,2:ncol(results_probfund)])/loops 
# } 

# 1 & 2) Create dataframe to hold results for mean +/- SD # Species Funded/Performance
# Numb Funded Species & Performance for each treatment 
BSCo_output <- data.frame(Treatment=rep("BSCo", nrow(sim_df)),
                          SimSet=sim_df$SimSet,
                          UBS=sim_df$UBS,
                          UCo=sim_df$UCo,
                          UBudget=sim_df$UBudget,
                          MeanFunded=round(BSCo_mean_funded,1), 
                          SDFunded=round(BSCo_sd_funded,2), 
                          MeanPerform=round(BSCo_mean_perform,1),
                          SDPerform=round(BSCo_sd_perform,2))

# Reattach names to the BSCo_probfund
names(BSCo_probfund) <- c("unique_plan_num", as.character(BSCo_output$SimSet))

# 3) Calculate which species are always/never funded funded for each uncertainty/budget treatment
# For each Treatment (column), subset where value >0.99 and count rows for Always.
# For each Treatment (column), subset where value == 0 and count rows for Never.
# df[df==""]<-NA
BSCo_always <- BSCo_probfund[,2:ncol(BSCo_probfund)]
BSCo_always[BSCo_always > 0.99] <- 1
BSCo_always[BSCo_always <= 0.99] <- NA
BSCo_always <- cbind(BSCo_probfund[,1], BSCo_always)

BSCo_sometimes <- BSCo_probfund[,2:ncol(BSCo_probfund)] 
BSCo_sometimes[BSCo_sometimes == 0.00] <- NA
BSCo_sometimes[BSCo_sometimes > 0.99] <- NA
BSCo_sometimes[!is.na(BSCo_sometimes)] <- 1
BSCo_sometimes <- cbind(BSCo_probfund[,1], BSCo_sometimes)

BSCo_never <- BSCo_probfund[,2:ncol(BSCo_probfund)] # Error in colSums(BSCo_never[, -1], na.rm = TRUE) : 'x' must be numeric
BSCo_never[BSCo_never != 0.00] <- NA
BSCo_never[BSCo_never == 0.00] <- 1
BSCo_never <- cbind(BSCo_probfund[,1], BSCo_never)

# How many species, for each treatment are always/never funded? Add each parameter treatment (B, Co, BCo etc), as it is completed.
BSCo_probfund_results<- data.frame(NULL)
BSCo_always<- colSums(BSCo_always[,-1], na.rm=TRUE)
BSCo_sometimes<- colSums(BSCo_sometimes[,-1], na.rm=TRUE)
BSCo_never<- colSums(BSCo_never[,-1], na.rm=TRUE)
BSCo_probfund_results<-rbind(BSCo_always, BSCo_sometimes, BSCo_never)
# datatable((BSCo_probfund_results))

################# End BSCo_Treatment ################




Output_3UBudget<-rbind(BSCo_output, BS_output, BCo_output, SCo_output, B_output, S_output, Co_output)

# write.csv(Output_3UBudget,"./output/Table1. Unformatted Output with 3 budget levels.csv")

Table1 <- Output_3UBudget %>%
    mutate(Budget=dollar(UBudget)) %>%
    arrange(UBS) %>% 
    arrange(UBudget) %>%
    arrange(Treatment) %>%
    select(-UBudget) %>%
    select( -UBS, -UCo) # Add -Treatment if I want to also remove 'BCo' column from this table)

Table1$Budget<-as.factor(Table1$Budget)
Table1<-Table1[,c(1,7,2:6)]
datatable(Table1, rownames=FALSE)

# write.csv(Table1, file="./output/Table 1. Mean Number of Species Funded and Performance for all treatments and parameter combinations.csv")





# Figure 1. Performance - with just 3 levels
# Output_3UBudget
ggplot(Output_3UBudget, aes(x = UBudget, y = MeanPerform, colour = UBS)) +
    geom_errorbar(aes(ymin = MeanPerform - SDPerform, ymax = MeanPerform + SDPerform), width = 0.1) +
    geom_line() +
    geom_point(size = 2) +  
    facet_grid(Treatment ~ UBS) +
    xlab("Budget") +
    ylab("Performance") +
    theme_bw()





#################################
final <-data.frame(NA) # I MUST HAVE SOMETHING IN HERE OR IT DOESN'T WORK. 
saved<- data.frame(NA)

for (i in (1:100))
{
    SU <- runif(length(data$S),(data$S-uncert[k]),(data$S+uncert[k]))   # CU, BU and SU are Cost Benefit and Success with Uncertainty
    SU[SU>1]<-1  
    
    BU <- runif(length(data$B),(data$B-uncert[k]),(data$B+uncert[k]))  
    BU[ BU>1]<-1  
    BU[ BU<0]<-0
    
    CU<-runif(length(data$Co),(data$Co*(1-uncert[k])),(data$Co*(1+uncert[k])))
    
    CEU <- ((BU*SU)/CU)
    
    simdata <-data.frame(data$species_id, data$spp_text, data$taxa_text, data$taxa_code, CU, CEU)
    
    simdata<-simdata[order(-simdata$CEU),]
    simdata$cumsum<-cumsum(simdata$CU)
    
    simdata$outcome = as.numeric(simdata$cumsum>= 3000000)
    simdata$outcome = ifelse(simdata$cumsum>= 3000000,0,1)
    
    outcomevec <- simdata[['outcome']]
    sums <- sum(outcomevec)
    #sums<- data.frame(sums)
    final<-cbind(final,sums)
    #saved<- cbind(saved,sums)
}