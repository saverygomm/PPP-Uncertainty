# Match $Outcomes to datasim 

datasim
results_probfund





# library(scales)

# Specify order for Decisions (shouldn't be needed if done above, but here for good measure)
Table3.tidy$Budget <- factor(Table3.tidy$Budget, c("L", "M", "H"))
Table3.tidy$Uncertainty <- factor(Table3.tidy$Uncertainty, c("Low", "Medium", "High"))
Table3.tidy$Parameter <- factor(Table3.tidy$Parameter, c("B", "S", "BS", "Co", "BCo", "SCo", "BSCo"))
Table3.tidy$Decision <- factor(Table3.tidy$Decision, c("always","sometimes","never"))




# Stacked bar plot of Always/Sometimes/Never for all treatments
cbbPalette <- c("#99CC66","#FF9933","#993333")
# Red    "FF3300" 990000
# Orange "FF6600" FF6633 FF9933
# Green  "33FF00" "#336600" 99CC66 99CC00

Figure3<- ggplot(Table3.tidy,aes(x = Budget, y = value , fill = Decision)) + 
    geom_bar(position = "fill",stat = "identity") +
    # or:
    # geom_bar(position = position_fill(), stat = "identity") 
    scale_y_continuous(labels = percent_format()) +
    facet_grid(Treatment ~ Uncertainty) +
    scale_fill_manual(values = cbbPalette) +
    xlab("Budget") +
    ylab("Proportion of Projects in Funded Portfolio") +
    ggtitle("Budget: ???? $0.75 million, $1.5 million, $3.0 million") # set up to work with sim_df

Figure3

# Stacked bar plot of Always/Sometimes/Never for JUST COST BENEFIT AND SUCCESS
# Subset & Reorganize
Table3.Figure3<-Table3.tidy %>%
    filter(Treatment %in% c("B", "S", "Co"))
Table3.Figure3$Treatment <-factor(Table3.Figure3$Treatment, c("B", "S", "Co"))
# View(Table3.Figure3)



# Creating a stacked bar graph with JUST BSCO/High. 



# Table3.tidy<-read.csv("./output/Table 3. TIDY Always_Never Funded Recovery Plans.csv")
Table3.tidy<-read.csv("./output/Run 5 - S is runif/Table 3. TIDY Always_Never Funded Recovery Plans.csv") # S is runif



# Specify order for Decisions (shouldn't be needed if done above, but here for good measure)
Table3.tidy$Budget <- factor(Table3.tidy$Budget, c("L", "M", "H"))
Table3.tidy$Uncertainty <- factor(Table3.tidy$Uncertainty, c("Low", "Medium", "High"))
Table3.tidy$Parameter <- factor(Table3.tidy$Parameter, c("B", "S", "BS", "Co", "BCo", "SCo", "BSCo"))
Table3.tidy$Decision <- factor(Table3.tidy$Decision, c("always","sometimes","never"))

library(tidyverse)

library(scales)

View(Table3.tidy)

# Stacked bar plot of Always/Sometimes/Never for JUST COST BENEFIT AND SUCCESS
# Subset & Reorganize
Table3.Figure3<-Table3.tidy %>%
    filter(Treatment %in% c("BSCo")) %>%
    filter(Uncertainty %in% c("High")) %>%
    filter(Budget %in% c("H"))

Table3.Figure3$Treatment <-factor(Table3.Figure3$Treatment, c("BSCo"))
Table3.Figure3$Uncertainty <-factor(Table3.Figure3$Uncertainty, c("High"))
Table3.Figure3$Budget <-factor(Table3.Figure3$Budget, c("H"))

View(Table3.Figure3)


cbbPalette <- c("#99CC66","#FF9933","#993333")
# Red    "FF3300" 990000
# Orange "FF6600" FF6633 FF9933
# Green  "33FF00" "#336600" 99CC66 99CC00

Figure4<- ggplot(Table3.Figure3,aes(x = Budget, y = value , fill = Decision)) + 
    geom_bar(position = "fill",stat = "identity") +
    # or:
    # geom_bar(position = position_fill(), stat = "identity") 
    scale_y_continuous(labels = percent_format()) +
    facet_grid(Treatment ~ Uncertainty) +
    scale_fill_manual(values = cbbPalette) +
    xlab("Budget") +
    ylab("Proportion of Projects in Funded Portfolio") +
    ggtitle("Budget: ???? $0.75 million, $1.5 million, $3.0 million") # set up to work with sim_df

Figure4
