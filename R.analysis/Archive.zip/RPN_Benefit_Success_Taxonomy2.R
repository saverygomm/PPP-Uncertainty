
# NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!
# NOTE!!!!! THERE ARE SOME MANUAL CHANGES THAT WILL NEED TO BE ADDED AFTER REWRITING!!!!!!!
# NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!

# title: Creating estimates of Benefit and Taxonomic Distinctiveness from USFWS Endangered Species Recovery Priority Numbers
# author: "S. Avery-Gomm
# date: "Aug 26, 2017"
# inputs: io-3137_b.csv     rpn query 3.csv
# outputs:  NoRPN Species.csv   RPN for USFWS PPP scaled NoRPNs imputed.csv
# R version 3.4.1 (2017-06-30)
# Platform: x86_64-apple-darwin15.6.0 (64-bit)
# Running under: macOS Sierra 10.12.5

# Objective:  
    # To assign each ESA listed species a Benefit and Taxonomic Distinctiveness based on it's Recovery Priority Number. 
    #   The trailing 'C' in the original Recovery Priority Numbers indicates 'Conflict.'For more information about the Recovery priority Numbers see https://www.fws.gov/endangered/esa-library/pdf/1983_LPN_Policy_FR_pub.pdf
    #   RPN_Benefit was derived by assigning a 1-3 value to the Degree of Threat (H, M, L). Feasibility based on a 1 or 0.5 value to the Recoverability Potential (0.01, Low).  Taxonomy (weighting for taxonomic distinctiveness) was assigned directly from RPN Taxonomy rankings, scaled to 1. Monotypic Genus = 1, Species = 0.67, Subspecies = 0.33
    # For multispecies plans, B & S will be the sum B & S for all unique_id/species within the multispecies plan. For Taxonomy, it will be the average, because the taxonomy weighting acts like a penelty, downweighting species that are not taxonomically distinct (subspecies)
    # For Uncertainty analyses ONLY values will need to be scaled so that they fall between 0.12 - 0.88 (i.e., (x*0.78)+0.12) for rbeta distribution simulations (NOT HERE)
    # For this project RPNs were only available for 1192 of the 1350 sp_vip_code (species, subspecies etc) that we had Recovery Plan data for. To fill in the NAs we interpolate based on values for other sp_vip_codes belonging to the same plan_id (aka unique_plan_id).

            # Table 1. Conversion of RPN numbers to RPN_TaxoWeighting and RPN_Benefit (also see Recovery Priority Number BENEFIT_TAXONOMY Scaled.xlsx)
            
            # Recoverability Potential (Benefit with Management)				Degree of Threat		Benefit 		Taxonomic Distinctiveness	
            # USFWS RPN Priority Rank 	Magnitude	Code	Scaled Value	Benefit with Management	Magnitude	Code	Scaled Value	Benefit without Mangement 	(Benefit with  management - Benfit without management)	Taxonomy_Weighting 	Taxonomy_Weighting  Code	Scaled Value
            # 1	High	3	1.00	1.00	High	3	0.99	0.01	0.99	Monotypic genus	3	0.99
            # 2	High	3	1.00	1.00	High	3	0.99	0.01	0.99	Species	2	0.66
            # 3	High	3	1.00	1.00	High	3	0.99	0.01	0.99	Subspecies	1	0.33
            # 4	Low	1.5	0.50	0.50	High	3	0.99	0.01	0.49	Monotypic genus	3	0.99
            # 5	Low	1.5	0.50	0.50	High	3	0.99	0.01	0.49	Species	2	0.66
            # 6	Low	1.5	0.50	0.50	High	3	0.99	0.01	0.49	Subspecies	1	0.33
            # 7	High	3	1.00	1.00	Moderate	2	0.66	0.34	0.66	Monotypic genus	3	0.99
            # 8	High	3	1.00	1.00	Moderate	2	0.66	0.34	0.66	Species	2	0.66
            # 9	High	3	1.00	1.00	Moderate	2	0.66	0.34	0.66	Subspecies	1	0.33
            # 10	Low	1.5	0.50	0.50	Moderate	2	0.66	0.34	0.16	Monotypic genus	3	0.99
            # 11	Low	1.5	0.50	0.50	Moderate	2	0.66	0.34	0.16	Species	2	0.66
            # 12	Low	1.5	0.50	0.50	Moderate	2	0.66	0.34	0.16	Subspecies	1	0.33
            # 13	High	3	1.00	1.00	Low	1	0.33	0.67	0.33	Monotypic genus	3	0.99
            # 14	High	3	1.00	1.00	Low	1	0.33	0.67	0.33	Species	2	0.66
            # 15	High	3	1.00	1.00	Low	1	0.33	0.67	0.33	Subspecies	1	0.33
            # 16	Low	1.5	0.50	0.50	Low	1	0.33	0.67	-0.17	Monotypic genus	3	0.99
            # 17	Low	1.5	0.50	0.50	Low	1	0.33	0.67	-0.17	Species	2	0.66
            # 18	Low	1.5	0.50	0.50	Low	1	0.33	0.67	-0.17	Subspecies	1	0.33

# INITIALIZING

    # Clear workspace
    rm(list=ls())
    gc()
    
    # Set Working Directory
#    setwd("/Users/stephanieavery-gomm/Dropbox/PhD/Brainstorming/PPP USA threatened species prioritisation/USA threatened species prioritisation (Southern Hemi group)/programs/RPN_Benefit_Taxonomy/")

  
    
    # Confirm Working Directory is correct
    getwd()
    
    # Load packages
    library(tidyverse) # tidyverse_1.1.1

### SET UP 
    
    # Import the RPN species file. Ensure file is CSV with a header row. Delete trailing spaces and set blank cells to NA
    RPNdata<- read.csv("./data/RPN custom query 3.csv", strip.white=TRUE, header=T, na.strings="")
    length(unique(RPNdata$sp_vip_code)) # 1298 sps_vip_codes with RPN data in the ECOS database

# Robb Harris, USFWS Contractor says: "There is a 'View' that populates the report pulling in recovery action, species associated, and gets those species and uses a document species current RPN which has 1298 unique sp_vip_id. Those are all the current RPNs. I talked to Stephanie here at USFWS who does a lot more of this stuff, and she says that's all the data they have on current RPN for active files. If you ever need to ask more questions, don't forget to quote the original ticket number"

        # How many duplicates are there of sp_vip_code in the recieved RPN dataset? 
        dim(RPNdata[duplicated(with(RPNdata, sp_vip_code)),]) # The answer to this should be 0 3 (i.e., zero rows). If there are some we may choose which RPN is correct based on the website https://ecos.fws.gov/ecp0/ore-input/ad-hoc-recovery-actions-public-report-input

    # Import the Recovery file with Species data. Ensure io-3137_b.csv is CSV with a header row. Delete trailing spaces and set blank cells to NA
    AllActions<- read.csv("C:/Users/uqgiacon/Dropbox/UQ Comp/Research/US PPP/USA threatened species prioritisation/data/io-3137_b.csv", strip.white=TRUE, header=T, na.strings="")
    length(unique(AllActions$sp_vip_code)) # 1350 sps_vip_codes in the ECOS database, total.
       
    # Subset out only the species data. Get one row for each sp_vip_code by using !duplicates
    UniqueSpeciesID <-AllActions[!duplicated(with(AllActions, sp_vip_code)),c(1,3,5,6,20,23)]
 
  
# For each sp_vip_code in io-3137_b.csv, fill in the corresponding RPN from the "RPN custom query 3.csv" file. 
    
        # 1) Start by keeping all 1350 sp_vip_code levels, and enter NA where RPN's missing.
        WRPN<-left_join(UniqueSpeciesID, RPNdata, by= "sp_vip_code")
        WRPN$sp_vip_code<-as.factor(WRPN$sp_vip_code)

        # 2) Missing RPNs?
        
            # a) Create and view dataframe with the sp_vip_codes that have no Recovery Prioirty Numbers (N= 158)
            NoRPN<-filter(WRPN, is.na(rpn))
            NoRPN <- droplevels(NoRPN)
            # write.csv(NoRPN, file='io-3137_b-sp_vip_codes_without_RPN_or_threat-status.csv.csv')

            
            # b) Simplify RPNs by dropping the trailing 'c' in the original Recovery Priority Numbers, which indicates 'Conflict.' We will not consider this in the assignment of Benefit or Taxonomy so it must be dropped 
            WRPN$RPN_noC = gsub("\\C$", "", WRPN$rpn)
            WRPN$RPN_noC<-as.numeric(WRPN$RPN_noC)
            unique(WRPN$RPN_noC)
            
            # But we DO want to create a variable that includes information as to whether or not the sp_vip_code is associated with confict (Y = 1, 0 = N)
            WRPN<-mutate(WRPN, Conflict = ifelse(grepl('\\C$',rpn), 1, 0))
            
            # c) New variable "USFWS_RPN_Available" added, and species assigned as 1/0 where 1 = Y and 0 = N. 
            WRPN <-WRPN %>%
                mutate("USFWS_RPN_Available" = ifelse(is.na(rpn), 0,1)) 
            
            # d) Assign values for benefit_with/without_mgmt and taxonomy based on available RPN numbers. 
        
            # e) Interpolate the missing values for those sp_vip_code with no RPN, which have membership in a multi-species recovery plan. 
    
            # f) Calc Benefit 
        
            # d) Assign values for benefit and taxonomy based on available RPN numbers. 
   

        # TAXONOMIC DISTINCTIVENESS
        # SCALED Create a new variable for taxonomy weightings RPN_TaxoWeighting based on the Taxonomy Distinctiveness element of the Recovery Priority Numbers 
        WRPN$RPN_TaxoWeighting<-NA
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "1"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "2"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "3"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "4"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "5"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "6"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "7"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "8"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "9"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "10"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "11"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "12"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "13"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "14"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "15"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "16"] <- "1" # Monotypic genus
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "17"] <- "0.67" # Species
        WRPN$RPN_TaxoWeighting[WRPN$RPN_noC == "18"] <- "0.33" # Subspecies
        WRPN$RPN_TaxoWeighting<- as.numeric(WRPN$RPN_TaxoWeighting)
        
        
        # WORDS Create a new variable for taxonomy weightings RPN_TaxoWeighting based on the Taxonomy Element of the Recovery Priority Numbers 
        WRPN$RPN_TaxoWeighting_char<-NA
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "1"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "2"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "3"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "4"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "5"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "6"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "7"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "8"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "9"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "10"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "11"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "12"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "13"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "14"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "15"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "16"] <- "Monotypic_genus"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "17"] <- "Species"
        WRPN$RPN_TaxoWeighting_char[WRPN$RPN_noC == "18"] <- "Subspecies"
        WRPN$RPN_TaxoWeighting_char<- as.character(WRPN$RPN_TaxoWeighting_char)
        
        # SUCCESS_1
        # Create a new variable for Feasibility (Success) that is scaled to 1
        WRPN$RPN_Success<-NA
        WRPN$RPN_Success <- "1" 
        WRPN$RPN_Success<-as.numeric(WRPN$RPN_Success)
        
        # SUCCESS_RUNIF
        # Create a new variable for Feasibility that is a random number from uniform distribution ranging from 0.5 to 1. 
        WRPN$RPN_Success_runif<-NA
        WRPN$RPN_Success_runif <- runif(nrow(WRPN), min = 0.5, max = 1) 
        WRPN$RPN_Success_runif<-as.numeric(WRPN$RPN_Success_runif)

        # DEGREE OF THREAT
        # WORDS Create a variable which is clearly "Degree of Threat" directly from RPN. 
        WRPN$RPN_Degree_of_Threat<-NA
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "1"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "2"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "3"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "4"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "5"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "6"] <- "High" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "7"] <- "Moderate"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "8"] <- "Moderate"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "9"] <- "Moderate"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "10"] <- "Moderate" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "11"] <- "Moderate"  
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "12"] <- "Moderate" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "13"] <- "Low" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "14"] <- "Low"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "15"] <- "Low"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "16"] <- "Low"
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "17"] <- "Low" 
        WRPN$RPN_Degree_of_Threat[WRPN$RPN_noC == "18"] <- "Low"
        
        WRPN$RPN_Degree_of_Threat<-as.character(WRPN$RPN_Degree_of_Threat)
        
        # WORDS Create a variable which is clearly RPN_Recoverability_Potential 
        WRPN$RPN_Recoverability_Potential<-NA
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "1"] <- "High" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "2"] <- "High" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "3"] <- "High" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "4"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "5"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "6"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "7"] <- "High"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "8"] <- "High"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "9"] <- "High"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "10"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "11"] <- "Low"  
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "12"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "13"] <- "High" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "14"] <- "High"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "15"] <- "High"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "16"] <- "Low"
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "17"] <- "Low" 
        WRPN$RPN_Recoverability_Potential[WRPN$RPN_noC == "18"] <- "Low"
        
        WRPN$RPN_Recoverability_Potential<-as.character(WRPN$RPN_Recoverability_Potential)
        
        #BENEFIT_WITH_MGMT
        # SCALED Create a variable which is clearly Benefit_with_Mgmt << This is equivilent to Recoverability Potential, scaled to 1. 
        WRPN$Benefit_with_Mgmt<-NA
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "1"] <- "1.00" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "2"] <- "1.00" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "3"] <- "1.00" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "4"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "5"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "6"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "7"] <- "1.00"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "8"] <- "1.00"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "9"] <- "1.00"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "10"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "11"] <- "0.50"  
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "12"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "13"] <- "1.00" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "14"] <- "1.00"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "15"] <- "1.00"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "16"] <- "0.50"
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "17"] <- "0.50" 
        WRPN$Benefit_with_Mgmt[WRPN$RPN_noC == "18"] <- "0.50"
        
        WRPN$Benefit_with_Mgmt<-as.numeric(WRPN$Benefit_with_Mgmt)
        
        # BENEFIT_WITHOUT_MGMT
        # SCALED Create a variable which is clearly Benefit_without_Mgmt << calculated as (1-Degree of Threat) where Degree of Threat is scaled to 1 
        WRPN$Benefit_without_Mgmt<-NA
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "1"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "2"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "3"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "4"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "5"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "6"] <- "0.01" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "7"] <- "0.34"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "8"] <- "0.34"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "9"] <- "0.34"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "10"] <- "0.34" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "11"] <- "0.34"  
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "12"] <- "0.34" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "13"] <- "0.67" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "14"] <- "0.67"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "15"] <- "0.67"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "16"] <- "0.67"
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "17"] <- "0.67" 
        WRPN$Benefit_without_Mgmt[WRPN$RPN_noC == "18"] <- "0.67"
        
        WRPN$Benefit_without_Mgmt<-as.numeric(WRPN$Benefit_without_Mgmt)
        
        
######### e) Interpolate the missing values for those sp_vip_code with no RPN, which have membership in a multi-species recovery plan. 
   
   # How many sp_vip_code in each plan_id? If = 1, impute.mean == NaN
   count_sp_vip_code <- WRPN %>%
        group_by(plan_id) %>%
        summarise(sp_vip_code_in_plan_id = length(unique(sp_vip_code)))
   WRPN <- left_join(WRPN,count_sp_vip_code, by = "plan_id")
   
   View(WRPN)
   str(WRPN)
   
    # Replace NA with average value for those sp_vip_code with no RPN - which have membership in a multi-species recovery plan.       
    library(plyr)
    impute.mean <- function(x) replace(x, is.na(x), mean(x, na.rm = TRUE))
    WRPN <- ddply(WRPN, ~ plan_id, transform, Benefit_with_Mgmt = impute.mean(Benefit_with_Mgmt),
                                               Benefit_without_Mgmt = impute.mean(Benefit_without_Mgmt),
                                               RPN_TaxoWeighting = impute.mean(RPN_TaxoWeighting))
    WRPN<-WRPN[order(WRPN$sp_vip_code), ] #plyr orders by group so we have to reorder
    detach(package:plyr)
    library(tidyverse) 

    # Where sp_vip_codes WITHOUT RPNs and NOT in multi-species plans, this will have introduced NaNs. Change to NA.
    WRPN<- WRPN %>%
        mutate(Benefit_with_Mgmt = ifelse(is.nan(Benefit_with_Mgmt), NA, Benefit_with_Mgmt)) %>%
        mutate(Benefit_without_Mgmt = ifelse(is.nan(Benefit_without_Mgmt), NA, Benefit_without_Mgmt)) %>%
        mutate(RPN_TaxoWeighting = ifelse(is.nan(RPN_TaxoWeighting), NA, RPN_TaxoWeighting)) 

    
######## f) Calc Benefit from Benefit_with/without_Mgmt
    
    # RPN_BENEFIT
    # Create variable RPN_Benefit based on the Recovery Priority Numbers. Here, Benefit of the Recovery Plan = (Benefit with Management) - (Benefit With Management) 
    # Where
    # Benefit Without Management = 1 - (Degree of Threat) 
    # Benefit With Management =  Recoverability Potential 
    WRPN<- mutate(WRPN, RPN_Benefit = Benefit_with_Mgmt - Benefit_without_Mgmt)
    # Note, where RPN = 16, 17 & 18 Benefit will be negative (00.17). 
    # Benefit for thes sp_vip_code ("S01O-P01", "A046-V01", "C01O-V01", "Q1TU-P01") were bumped to 0.001 for the sake of the CEA.
    WRPN<-mutate(WRPN, RPN_Benefit = ifelse(RPN_Benefit < 0, 0.001, RPN_Benefit))
    
    View(WRPN)

    # # Export
    # write.csv(WRPN, file="RPN for USFWS PPP scaled NoRPNs imputed.csv", row.names = F)
    
    
    # NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!
    # NOTE!!!!! THERE ARE SOME MANUAL CHANGES THAT WILL NEED TO BE ADDED AFTER REWRITING!!!!!!!
    # NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!NOTE!!!!!
    
    
    # There are several action_species which have 2 sps_vip_code (listed below). Some of these sps_vip_codes don't have an RPN, but they do have unique_plan_num associated with them. This was thought to be a possible source of error in the AllPPPOutput.csv produced by Gwen Feb 20, 2018. So, I went through each of these action_species and verified that the lack of RPN was TRUE, and not an error in coding. 
    
     # For A07X-V01 (Mariana fruit Bat (=Mariana flying fox) (Pteropus mariannus mariannus)) I assigned RPN manually from sp_vip_code A07X-V04, after verifying that the ECOS website indicates only one population. I am not sure why there are two unique_plan_id 
    # For B07C-V01 (Western snowy plover (Charadrius alexandrinus nivosus)) I assigned RPN manually from sp_vip_code B07C-V01, which has same species name. Checked ECOS, there is only one listing. Not sure why there are two unique_plan_id.
    # For the rest, if there is no RPN it is bc the RPN was truely missing (likely bc the species was delisted or it was never assigned
    
            # 2 sps_vip_codes per action_species in RPN for USFWS PPP scaled NoRPNs imputed.csv
                # Bull Trout (Salvelinus confluentus)
                # Columbian white-tailed deer (Odocoileus virginianus leucurus)
                # Green sea turtle (Chelonia mydas)
                # Mariana fruit Bat (=Mariana flying fox) (Pteropus mariannus mariannus)
                # Mexican wolf (Canis lupus baileyi)
                # Olive ridley sea turtle (Lepidochelys olivacea)
                # Piping Plover (Charadrius melodus)
                # Roseate tern (Sterna dougallii dougallii)
                # Western snowy plover (Charadrius alexandrinus nivosus)
            
            # 3 sps_vip_codes per action_species in RPN for USFWS PPP scaled NoRPNs imputed.csv
                # Loggerhead sea turtle (Caretta caretta)