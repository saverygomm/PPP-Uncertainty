# Here I am testing out Richard's idea. Figuring out what the prob fund is for the species at the point where the budget runs out.

BSCo_probfund <- read.csv("./output/BSCo_probfund.csv")
dataSpp <- read.csv("./output/dataSpp.csv")

head(BSCo_probfund)
str(BSCo_probfund)

# Get dataSpp to project level
datasim <- dataSpp
dataproj <- datasim %>%
    group_by(unique_plan_num) %>%
    summarise(
        RPN_Benefit = sum(RPN_Benefit, na.rm = TRUE),
        RPN_Success = mean(RPN_Success, na.rm = TRUE), # why isn't the max of this 1?
        RPN_Cost_annual = mean(Co, na.rm = TRUE)/50)

# Set up for CEA 
dataproj <- dataproj %>%
    mutate(CE=((RPN_Benefit*RPN_Success)/RPN_Cost_annual)) %>%
    arrange(desc(CE)) %>%
    mutate(CumSum=cumsum(RPN_Cost_annual)) %>%
    mutate(Rank = rank(1/CE)) %>%
    arrange(Rank)

# View(dataproj)

# Force datasim to include a rank order as an additional column after CE assessed. Should I calculate the average rank?
BSCo_probfund$unique_plan_num<-as.factor(BSCo_probfund$unique_plan_num)
test<- left_join(BSCo_probfund, dataproj, by = "unique_plan_num")

# Baseline/BudgetsHML
test1 <- test %>% mutate(Outcome_BudgetH = ifelse(CumSum >= sim_df[1,4], 0, 1)) %>% # Budget levels from sim_df
    mutate(Outcome_BudgetM = ifelse(CumSum >= sim_df[2,4], 0, 1)) %>%
    mutate(Outcome_BudgetL = ifelse(CumSum >= sim_df[3,4], 0, 1))           

# Re calculate CumSum and Outcome for each SimSet.
test2 <- test1 %>%
    select(unique_plan_num, RPN_Benefit, RPN_Success, RPN_Cost_annual, CE, Rank, CumSum, LLL, MML, HHL, LLM, MMM, HHM, LLH, MMH, HHH) %>%
    arrange(Rank) %>%
    arrange(desc(LLL)) %>%
    mutate(CumSum_LLL=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_LLL = ifelse(CumSum_LLL >= sim_df[1,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(MML)) %>%
    mutate(CumSum_MML=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_MML = ifelse(CumSum_MML >= sim_df[1,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(HHL)) %>%
    mutate(CumSum_HHL=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_HHL = ifelse(CumSum_HHL >= sim_df[1,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(LLM)) %>%
    mutate(CumSum_LLM=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_LLM = ifelse(CumSum_LLM >= sim_df[2,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(MMM)) %>%
    mutate(CumSum_MMM=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_MMM = ifelse(CumSum_MMM >= sim_df[2,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(HHM)) %>%
    mutate(CumSum_HHM=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_HHM = ifelse(CumSum_HHM >= sim_df[2,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(LLH)) %>%
    mutate(CumSum_LLH=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_LLH = ifelse(CumSum_LLH >= sim_df[3,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(MMH)) %>%
    mutate(CumSum_MMH=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_MMH = ifelse(CumSum_MMH >= sim_df[3,4], 0, 1)) %>%
    arrange(Rank) %>%
    arrange(desc(HHH)) %>%
    mutate(CumSum_HHH=cumsum(RPN_Cost_annual)) %>%
    mutate(Outcome_Budget_HHH = ifelse(CumSum_HHH >= sim_df[3,4], 0, 1))

# Rearrange columns for easier reading
test3 <- test2 %>%
    select(unique_plan_num, RPN_Benefit, RPN_Success,RPN_Cost_annual,  CE, Rank, CumSum, LLL, CumSum_LLL, Outcome_Budget_LLL, MML, CumSum_MML, Outcome_Budget_MML, HHL, CumSum_HHL, Outcome_Budget_HHL, LLM, CumSum_LLM, Outcome_Budget_LLM, MMM, CumSum_MMM, Outcome_Budget_MMM, HHM, CumSum_HHM, Outcome_Budget_HHM, LLH, CumSum_LLH, Outcome_Budget_LLH, MMH, CumSum_MMH, Outcome_Budget_MMH, HHH, CumSum_HHH, Outcome_Budget_HHH)


write.csv(test3, "./output/test3.csv", row.names = FALSE)