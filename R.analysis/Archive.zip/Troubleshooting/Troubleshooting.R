
##############################################################################################################################
# Troubleshooting: Why is the cumulative sum (annual) cost of projects in 'always fund' category (i.e., probability of being in the funded portfolio given their CE score is 1) exceeding the allowable budget (when uncertainty only in BS - i.e, cost isconstant)? # ##############################################################################################################################


# How is my loop looking? See any glaring errors? 
# There is SOMETHING wrong with it - because the cumulative annual cost (i.e., Co/50) of Recovery Plans (unique_plan_num) in the 'Always Fund' category (i.e., prob_being_funded == 100%) exceeds the budget (e.g., $7,500,000) EVEN WHEN there is no uncertainty in cost (it is constant and won't confuse things by varying from run to run). Below, I trouble shoot this by
    # 1) duplicating the treatment where high medium and low levels of uncertainty are introduced into Benefit and Success. 
    # 2) choosing only the Low Budget, High Uncertainty Treatment, subetting out unique_plan_num where prob_being_funded == 1, and summing the annual costs. It exceeds the budget. 

# My sessionInfo() at end. 


            # ALERT! arrange on dataSpp. But better to drop in based on function match - look this up in dplyr/purr Use this for unique_plan_num rather than using arrange. Be wary of ... 

# PART 1) 
###### test_Treatment (aka BS_Treatment) ###############################

# Clear workspace 
rm(list=ls())
gc()

# Confirm Working Directory is correct
getwd()

# Load Packages
library(magrittr)
library(DT)
library(ggplot2)
library(plotly)
library(tidyverse) # loading in ddplyr THEN plyr this can create issues. tidyverse package overcomes that.
library(shiny)
library(scales)
library(reshape2)
# library(shinyapps) # Not available for R version 3.3.1

# Set Seed for truely reproducible random results
set.seed(3)

# Disable Scientific Notation (?getOption("scipen"))
options(scipen=999)

# Load files
dataSpp<- read.csv("./R.analysis/Troubleshooting/dataSpp.csv")
dataSpp<- dataSpp %>%
    arrange(unique_plan_num)

sim_df<-read.csv("./R.analysis/Troubleshooting/sim_df.chosen.csv")

source("./R.analysis/Troubleshooting/rBeta.R")


# FIRST FOR BENEFIT AND SUCCESS ONLY

# Check for BS
# BS_probfund<-read.csv("./output/Run 12 Nov 21 2017/BS_probfund.csv")
# BS_probfund_results<-read.csv("./output/Run 12 Nov 21 2017//BS_probfund_results.csv")
# BS_output <- read.csv("./output/Run 12 Nov 21 2017/BS_output.csv")

# Check for BSCO (comment out above, change XX_probfund in 2 places below, in Table2a.test.tidy and rerun. Confirm that totalannualCo doesn't exceed Budget)
BSCo_probfund<-read.csv("./output/Run 12 Nov 21 2017/BSCo_probfund.csv")
BSCo_probfund_results<-read.csv("./output/Run 12 Nov 21 2017/BSCo_probfund_results.csv")
BSCo_output <- read.csv("./output/Run 12 Nov 21 2017/BSCo_output.csv")






# What is the cumulative sum of projects in 'always fund' category when uncertainty is in B & S (cost is constant)?

# Create tidy dataframe using test (same as BS_probfund) uncertainty treatment

Table2a.test.tidy <- BSCo_probfund %>%
    melt(ind = rownames(BSCo_probfund), id.vars = "unique_plan_num", measure.vars = c("LLH", "LLM", "LLL", "MMH", "MMM", "MML", "HHH", "HHM", "HHL"))   %>%
    separate(variable, into = c("Uncertainty", "Budget"), sep = 2) %>%
    mutate(Uncertainty = ifelse(Uncertainty == "HH", "High",
                                ifelse(Uncertainty =="MM", "Medium",
                                       ifelse(Uncertainty == "LL", "Low", "NO VALUE")))) %>%
    mutate(Budget = ifelse(Budget == "H", sim_df[1,4],
                           ifelse(Budget =="M", sim_df[2,4],
                                  ifelse(Budget == "L", sim_df[3,4], "NO VALUE")))) %>%
    mutate(Budget = dollar(as.numeric(Budget))) %>%
    arrange(Budget, Uncertainty, unique_plan_num) %>%
    mutate(prob_being_funded = value) %>%
    select(-value)


datatable(Table2a.test.tidy, rownames=TRUE)

# Must set up a file with unique(unique_plan_num) characteristic data to get COST data. COST data originates from AllOutput.csv, which incorporates inflation. 
trim <- dataSpp[!duplicated(with(dataSpp, unique_plan_num)),c(1:28)]
trim <- trim %>%
    select(unique_plan_num, Co) %>%
    mutate(annualCo = (Co/50)) # In the CEA, cost is spread over 50 years. Here we are testing if annual budget exceeded. Annual budget is e.g. 7,500,000 per year

trim$unique_plan_num <- as.factor(trim$unique_plan_num)
Table2a.test.tidy$unique_plan_num <- as.factor(Table2a.test.tidy$unique_plan_num)

str(trim)
str(Table2a.test.tidy)

summarise(trim, total = sum(Co)) # $605400272390for all plans, total.
summarise(trim, total = sum(annualCo)) # $12108005448 for all plans, per year. 
View(trim)

# Join cost data with prob fund data
test<- left_join(Table2a.test.tidy, trim, by = "unique_plan_num")
View(test)

# Examine the subset of Low uncertainty Low budget...
# This demonstrates that the cumulative sum of projects in the 'Always Fund' category (i.e., prob fund == 100%) exceed the budget EVEN WHEN there is no uncertainty in cost (and so it should not vary from run to run)

    test %>%
        group_by(Budget, Uncertainty) %>%
        arrange(desc(prob_being_funded)) %>%
        mutate(CumSum_annualCo=cumsum(annualCo)) %>%
        filter(prob_being_funded >= 1) %>%
        summarise(totalCo = sum(Co),
                  totalannualCo = sum(annualCo))
         # checks out for BS_probfund
  

    
# Now, what is the probability of funding at the point when the budget runs out HIGH uncertainty?  
    LowOnly<- test %>% 
        filter(Uncertainty == "High") %>%
        filter(Budget == "$7,500,000") %>%
        arrange(desc(prob_being_funded)) %>%
        mutate(CumSum_annualCo=cumsum(annualCo)) %>%
        filter(CumSum_annualCo < 7500000)
    View(LowOnly)
    nrow(LowOnly)
    
    LowOnly %>%
        summarise(prob_at_cutoff = min(prob_being_funded))
    
    MedOnly <- test %>% 
        filter(Uncertainty == "High") %>%
        filter(Budget == "$15,000,000") %>%
        arrange(desc(prob_being_funded)) %>%
        mutate(CumSum_annualCo=cumsum(annualCo)) %>%
        filter(CumSum_annualCo < 15000000) 
    View(MedOnly)
    nrow(MedOnly)
    
    MedOnly %>%
        summarise(prob_at_cutoff = min(prob_being_funded))
    
    
    HighOnly <- test %>% 
        filter(Uncertainty == "High") %>%
        filter(Budget == "$30,000,000") %>%
        arrange(desc(prob_being_funded)) %>%
        mutate(CumSum_annualCo=cumsum(annualCo)) %>%
        filter(CumSum_annualCo < 30000000) 
    View(HighOnly)    
    nrow(HighOnly)
    
    HighOnly %>%    
        summarise(prob_at_cutoff = min(prob_being_funded))


########################## Stephanie's sessionInfo() ########################## 

# R version 3.4.1 (2017-06-30)
# Platform: x86_64-apple-darwin15.6.0 (64-bit)
# Running under: macOS Sierra 10.12.6
# 
# Matrix products: default
# BLAS: /System/Library/Frameworks/Accelerate.framework/Versions/A/Frameworks/vecLib.framework/Versions/A/libBLAS.dylib
# LAPACK: /Library/Frameworks/R.framework/Versions/3.4/Resources/lib/libRlapack.dylib
# 
# locale:
#     [1] en_CA.UTF-8/en_CA.UTF-8/en_CA.UTF-8/C/en_CA.UTF-8/en_CA.UTF-8
# 
# attached base packages:
#     [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#     [1] cowplot_0.8.0   bindrcpp_0.2    reshape2_1.4.2  scales_0.4.1    shiny_1.0.4     dplyr_0.7.2     purrr_0.2.3     readr_1.1.1    
# [9] tidyr_0.7.0     tibble_1.3.3    tidyverse_1.1.1 plotly_4.7.1    ggplot2_2.2.1   DT_0.2          magrittr_1.5   
# 
# loaded via a namespace (and not attached):
#     [1] tidyselect_0.1.1  haven_1.1.0       lattice_0.20-35   colorspace_1.3-2  htmltools_0.3.6   viridisLite_0.2.0 yaml_2.1.14      
# [8] rlang_0.1.2       foreign_0.8-69    glue_1.1.1        modelr_0.1.1      readxl_1.0.0      bindr_0.1         plyr_1.8.4       
# [15] stringr_1.2.0     munsell_0.4.3     gtable_0.2.0      cellranger_1.1.0  rvest_0.3.2       htmlwidgets_0.9   evaluate_0.10.1  
# [22] psych_1.7.5       labeling_0.3      knitr_1.17        forcats_0.2.0     httpuv_1.3.5      parallel_3.4.1    broom_0.4.1      
# [29] Rcpp_0.12.12      xtable_1.8-2      backports_1.1.0   jsonlite_1.5      mime_0.5          mnormt_1.5-5      hms_0.3          
# [36] digest_0.6.12     stringi_1.1.5     rprojroot_1.2     grid_3.4.1        tools_3.4.1       lazyeval_0.2.0    pkgconfig_2.0.1  
# [43] data.table_1.10.4 xml2_1.1.1        lubridate_1.6.0   rmarkdown_1.6     assertthat_0.2.0  httr_1.3.0        R6_2.2.2         
# [50] nlme_3.1-131      compiler_3.4.1   
# 
# 
