##################### # What is the cumulative sum of projects in 'always fund' category when uncertainty only in B (which doesn't affect cost)? # #####################


```{r troubleshoot}

# Sept 19. 
# What is the cumulative sum of projects in 'always fund' category when uncertainty only in B (which doesn't affect cost)? 

# Read in 
sim_df<-read.csv("./output/sim_df.chosen.csv")
B_probfund<-read.csv("./output/Run 7 - S is runif - to Ashton/B_probfund.csv")
dataSpp <- read.csv("./output/Run 7 - S is runif - to Ashton/dataSpp.csv")

# Create tidy dataframe for JUST B uncertainty treatment

Table2a.B.tidy <- B_probfund %>%
    melt(ind = rownames(B_probfund), id.vars = "unique_plan_num", measure.vars = c("LLH", "LLM", "LLL", "MMH", "MMM", "MML", "HHH", "HHM", "HHL"))   %>%
    separate(variable, into = c("Uncertainty", "Budget"), sep = 2) %>%
    mutate(Uncertainty = ifelse(Uncertainty == "HH", "High",
                                ifelse(Uncertainty =="MM", "Medium",
                                       ifelse(Uncertainty == "LL", "Low", "NO VALUE")))) %>%
    mutate(Budget = ifelse(Budget == "H", sim_df[1,4],
                           ifelse(Budget =="M", sim_df[2,4],
                                  ifelse(Budget == "L", sim_df[3,4], "NO VALUE")))) %>%
    mutate(Budget = dollar(as.numeric(Budget))) %>%
    arrange(Budget, Uncertainty, unique_plan_num)

datatable(Table2a.B.tidy, rownames=TRUE)

# Extract just cost and unique_plan_num with only one row per unique_plan_num

str(dataSpp)
dim(dataSpp)
UniquedataSpp <-dataSpp[!duplicated(with(dataSpp, unique_plan_num)),c(1:28)]

dim(UniquedataSpp)
UniquedataSpp.Co <- UniquedataSpp %>%
    select(unique_plan_num, Co) %>%
    mutate(annualCo = (Co/50)) # Of course, we are spending 7,500,000 per year for 50 years. So divide Co/50 to get annual costs. 

UniquedataSpp.Co$unique_plan_num <- as.factor(UniquedataSpp.Co$unique_plan_num)
Table2a.B.tidy$unique_plan_num <- as.factor(Table2a.B.tidy$unique_plan_num)

str(UniquedataSpp.Co)
str(Table2a.B.tidy)


summarise(UniquedataSpp.Co, total = sum(Co)) # $40,475,182,254 for all plans, total.
summarise(UniquedataSpp.Co, total = sum(annualCo)) # $809,503,645 for all plans, per year.


# Join cost data with prob fund data
test<- left_join(Table2a.B.tidy, UniquedataSpp.Co, by = "unique_plan_num")
View(test)

# Examine the subset of Low uncertainty Low budget... 
LowOnly<- test %>%
    filter(Budget == "$7,500,000") %>%
    filter(Uncertainty == "High") %>%
    arrange(desc(value)) %>%
    mutate(CumSum_annualCo=cumsum(annualCo))

View(LowOnly)
str(LowOnly)


# This demonstrates that the cumulative sum of projects in the 'Always Fund' category (i.e., prob fund == 100%) exceed the budget ($7,500,000) EVEN WHEN there is no uncertainty in cost (and so it would not vary from run to run)

LowOnly %>%
    filter(value == 1) %>%
    summarise(totalCo = sum(Co),
              totalannualCo = sum(annualCo))

# totalCo           totalannualCo
# 13468832718     269376654




```

